module.exports = {
  '{,src/**/}*.{json,md,yml}': ['prettier --write', 'git add']
};
