/**
 * Spring Data JPA repositories.
 */
package com.boa.api.repository;
