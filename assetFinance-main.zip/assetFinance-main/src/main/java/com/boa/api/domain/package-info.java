/**
 * JPA domain objects.
 */
package com.boa.api.domain;
