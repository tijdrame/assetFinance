/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package com.boa.api.service.mapper;
